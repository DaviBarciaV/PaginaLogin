document.querySelector(".login-form").addEventListener("submit", function(event) {
    event.preventDefault(); // Previne o envio do formulário para validação

    // Obtendo os valores dos campos
    const email = document.getElementById("email").value.trim();
    const senha = document.getElementById("senha").value.trim();

    // Regex para validar e-mail
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

     // Mensagem de validação
    if (!emailRegex.test(email)) {
        alert("Por favor, insira um e-mail válido.");
    } else if (senha.length < 6) {
        alert("A senha deve ter pelo menos 6 caracteres.");
    } else {
        alert("Login realizado com sucesso!");
        }
    });
